<!doctype html> 
<html lang="en"> 
<head> 

<title>DIGESTO - H.C.D.</title> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!--<link rel="stylesheet"  href="css/jquery.mobile-1.2.0.css" />
<script src="js/jquery.js"></script>
<script src="js/jquery.mobile-1.2.0.js"></script>
-->
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.css" />
<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.js"></script>

<script type="text/javascript" charset="utf-8" src="js/cordova-2.0.0.js"></script>

</head> 
<div id="Layer1" style="position:absolute;  background:#d8501f; left:1px; top:1px; width:1300px; height:100642px; z-index:1"> 

<div data-role="footer" data-id="nav"> 
<div data-role="navbar"> 







<ul>
<li><a href="index.html" data-icon="home">Home</a></li>
<li><a href="rama.html" data-icon="grid">Leyes por Rama</a></li>
<li><a href="consultas.html" data-icon="search" class="ui-btn-active ui-state-persist">Consultas</a></a></li> 
</ul>
</div>
</div>  
<font face=arial, size=2px, color=#FFF> 

<form action="http://www.hcdcorrientes.gov.ar/digesto/legislacion/buscasimple105dip.php" method="post" data-ajax="false" data-transition="flip"> 
<?
$NL =utf8_encode($_POST['NL']);
$Voz =utf8_encode($_POST['Voz']);
$Subvoz =utf8_encode($_POST['Subvoz']);
$Extracto =utf8_encode($_POST['Extracto']);
$Sancion =utf8_encode($_POST['Sancion']);
$Promulgacion =utf8_encode($_POST['Promulgacion']);
$Observaciones =utf8_encode($_POST['Observaciones']);
$PBO =utf8_encode($_POST['PBO']);
$es =utf8_encode($_POST['es']);
$materia =utf8_encode($_POST['materia']);
$nlm =utf8_encode($_POST['nlm']);
$modi =utf8_encode($_POST['modi']);
$regla =utf8_encode($_POST['regla']);
$reglad =utf8_encode($_POST['reglad']);
$audio =utf8_encode($_POST['audio']);
$braille =utf8_encode($_POST['braille']);


$host="localhost";
$usuarioh="neito1965";
$claveh="neItoMaVr$1965";
	$enlace = mysql_connect($host,$usuarioh,$claveh);
	mysql_set_charset('utf8', $enlace);
	mysql_select_db("legislatura2015", $enlace); 

if ($NL<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1  WHERE NL LIKE '$NL' ORDER BY NL ASC";

}if ($Voz<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE Voz LIKE '%$Voz%' ORDER BY NL ASC";

}if ($Subvoz<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE Subvoz LIKE '%$Subvoz%' ORDER BY NL ASC";

}if ($Extracto<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE Extracto LIKE '%$Extracto%' ORDER BY NL ASC";

}if ($Sancion<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE Sancion LIKE '%$Sancion%' ORDER BY NL ASC";

}if ($Promulgacion<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE Promulgacion LIKE '%$Promulgacion%' ORDER BY NL ASC";

}if ($Observaciones<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE Observaciones LIKE '%Observaciones%' ORDER BY NL ASC";

}if ($PBO<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE PBO LIKE '%$PBO%' ORDER BY NL ASC";

}if ($es<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE es LIKE '%$es%' ORDER BY NL ASC";

}if ($materia<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE materia LIKE '%$materia%' ORDER BY NL ASC";

}if ($nlm<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE nlm LIKE '%$nlm%' ORDER BY NL ASC";

}if ($modi<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE modi LIKE '%$modi%' ORDER BY NL ASC";

}if ($regla<>"") {
$SQL1="SELECT* FROM leyesydecretosleyesvigentes1 WHERE regla LIKE '%$regla%' ORDER BY NL ASC";

}
 


$result=mysql_query($SQL1,$enlace);

$numero = mysql_num_rows($result); // obtenemos el número de filas

echo 'El número de registros de leyes encontrados es: '.$numero.'';  // imprimos en pantalla el número generado



if ($row=mysql_fetch_array ($result)){ 

echo "<table border = '1'> \n"; 

echo "<tr BGCOLOR=#400080> \n";


echo "<th><font face=arial, size=1px, color=#FFF>Nro. Ley/DLey</th> \n";
echo "<th><font face=arial, size=1px, color=#FFF>Tema</th> \n";
echo "<th><font face=arial, size=1px, color=#FFF>Subtema</th> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Vigencia</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Texto original de la Ley/DL</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Texto actualizado de la Ley/DL</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Audio Ley/DL</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Braille Ley/DL</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Con o sin Modificación</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Reglamentación</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Link de reglamentación</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Extracto</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Fecha Sanción</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Fecha Promulgación</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Observaciones</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Fecha P.B.O.</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Materia</td> \n";

echo "</tr> \n";


while ($field = mysql_fetch_field($result)){ 

echo "<td><b>$field->name</b></td> \n"; 

} 

echo "</tr> \n"; 
do { 
echo "<tr BGCOLOR=#FFF> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['NL'])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["Voz"])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["Subvoz"])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["es"])."</td> \n";
$valor2=$row["NL"];
$valor2=implode('-',explode('/',$valor2));
$valor3=implode('-',explode('/',$valor2));



echo "<td><a href=http://www.hcdcorrientes.gov.ar/Leyes-texto/Ley$valor2.pdf target='_BLANK'><font face=verdana, size=1px, color=#EB0101>Ley</font></A> </td>";


if ($row['ta'] == 's') {
       echo "<td><font face=verdana, size=1px, color=#DD0000><a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/textos-actualizados/Ley$valor2.pdf' target='_BLANK'><font face=verdana, size=1px, color=#DD0000>Texto actualizado de la Ley</a></td> \n";
       //echo "<td><font face=verdana, size=1px, color=#DD0000><a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/braille/$valor2.pdf' target='_BLANK'><font face=verdana, size=1px, color=#DD0000>Ley en braille</a></td> \n";
  } else {
	   echo "<td><font face=verdana, size=1px, color=#0000FF>Esta Ley no tiene texto actualizado</td> \n";
	   //echo "<td><font face=verdana, size=1px, color=#0000FF>Ley sin braille</td> \n";
	
  }





if ($row['audio'] == 's') {
       echo "<td><font face=verdana, size=1px, color=#DD0000><a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/audio/$valor2.mp3' target='_BLANK'><font face=verdana, size=1px, color=#DD0000>Ley c/audio</a></td> \n";
       //echo "<td><font face=verdana, size=1px, color=#DD0000><a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/braille/$valor2.pdf' target='_BLANK'><font face=verdana, size=1px, color=#DD0000>Ley en braille</a></td> \n";
  } else {
	   echo "<td><font face=verdana, size=1px, color=#0000FF>Ley s/audio</td> \n";
	   //echo "<td><font face=verdana, size=1px, color=#0000FF>Ley sin braille</td> \n";
	
  }



if ($row['braille'] == 's') {
       //echo "<td><font face=verdana, size=1px, color=#DD0000><a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/audio/$valor2.mp3' target='_BLANK'><font face=verdana, size=1px, color=#DD0000>Ley c/audio</a></td> \n";
       echo "<td><font face=verdana, size=1px, color=#DD0000><a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/braille/$valor2.pdf' target='_BLANK'><font face=verdana, size=1px, color=#DD0000>Ley en braille</a></td> \n";
  } else {
	   //echo "<td><font face=verdana, size=1px, color=#0000FF>Ley s/audio</td> \n";
	   echo "<td><font face=verdana, size=1px, color=#0000FF>Ley sin braille</td> \n";
	
  }



if ($row['modi'] == 'Con modificaciones') {

echo "<td><font face=verdana, size=1px, color=#DD0000><a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/$valor3.php' target='_BLANK'><font face=verdana, size=1px, color=#DD0000>".utf8_decode($row["modi"])."</a></td> \n";
} else {
	echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["modi"])."</td> \n";
	//echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["regla"])."</td> \n";
}

//$valor4=$row["reglad"];
//$valor5=implode('-',explode('/',$valor4));
if ($row['regla'] == 'Reglamentada') {
       echo "<td><font face=verdana, size=1px, color=#DD0000>".utf8_decode($row["regla"])."</td> \n";
 } else
if ($row['regla'] == 'Complementarias') {
        echo "<td><font face=verdana, size=1px, color=#DD0000>".utf8_decode($row["regla"])."</td> \n";
 } else {
        echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["regla"])."</td> \n";
	
 }


$valor7=$row["reglad"];
$valor8=implode('-',explode('/',$valor7));

$valor9=$row["reglad1"];
$valor10=implode('-',explode('/',$valor9));

$valor11=$row["reglad2"];
$valor12=implode('-',explode('/',$valor11));

$valor13=$row["reglad3"];
$valor14=implode('-',explode('/',$valor13));

$valor15=$row["reglad4"];
$valor16=implode('-',explode('/',$valor15));

$valor17=$row["reglad5"];
$valor18=implode('-',explode('/',$valor17));

$valor19=$row["reglad6"];
$valor20=implode('-',explode('/',$valor19));

$valor21=$row["reglad7"];
$valor22=implode('-',explode('/',$valor21));

$valor23=$row["reglad8"];
$valor24=implode('-',explode('/',$valor23));

//$cadena =$row['reglad']; 
 
//$resultado8 = intval(preg_replace('/[^0-9]+/', '', $valor8), 10); 
 
//echo $resultado8; // resultado: 102030

echo "<td><font face=verdana, size=1px, color=#0000FF><a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/decretos-reglamentarios/Decreto$valor8.pdf' target='_BLANK'>".utf8_decode($row["reglad"])."\n
<a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/decretos-reglamentarios/Decreto$valor10.pdf' target='_BLANK'>".utf8_decode($row["reglad1"])."\n
<a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/decretos-reglamentarios/Decreto$valor12.pdf' target='_BLANK'>".utf8_decode($row["reglad2"])."\n
<a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/decretos-reglamentarios/Decreto$valor14.pdf' target='_BLANK'>".utf8_decode($row["reglad3"])."\n
<a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/decretos-reglamentarios/Decreto$valor16.pdf' target='_BLANK'>".utf8_decode($row["reglad4"])."\n
<a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/decretos-reglamentarios/Decreto$valor18.pdf' target='_BLANK'>".utf8_decode($row["reglad5"])."\n
<a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/decretos-reglamentarios/Decreto$valor20.pdf' target='_BLANK'>".utf8_decode($row["reglad6"])."\n
<a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/decretos-reglamentarios/Decreto$valor22.pdf' target='_BLANK'>".utf8_decode($row["reglad7"])."\n
<a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/decretos-reglamentarios/Decreto$valor24.pdf' target='_BLANK'>".utf8_decode($row["reglad8"])."\n
</a></td> \n";

echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["Extracto"])."</td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["Sancion"])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["Promulgacion"])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["Observaciones"])."</td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["PBO"])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["materia"])."</td> \n";

 
} while ($row = mysql_fetch_array($result)); 

echo "</table> \n"; 


} else { 
$Rc=$Rc+1


?>


  <script language="JavaScript">     
		window.top.location ="http://www.hcdcorrientes.gov.ar/digesto/legislacion/consultaavanzada.html";    
		alert("Esta Ley o Decreto Ley que esta consultando no esta mas vigente");
        
	    
</script>




<?

}
?>
 


</div>


  </form>
</div>
</body>
</html>
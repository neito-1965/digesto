<?php 

// Defininicion de constants
define( "RECIPIENT_NAME", "Juan Perez" ); 
define( "RECIPIENT_EMAIL", "jperez@yahoo.com" ); 
define( "EMAIL_SUBJECT", "Mensaje de usuario" ); 


// Lee los valores que recibe del formulario 
$success = false; 
$senderName = isset( $_POST['senderName'] ) ? preg_replace( "/[^\.\-\' a-zA-Z0-9]/", "", $_POST['senderName'] ) : ""; 
$senderEmail = isset( $_POST['senderEmail'] ) ? preg_replace( "/[^\.\-\_\@a-zA-Z0-9]/", "", $_POST['senderEmail'] ) : ""; 

$productCategories = array(); 

if ( isset( $_POST['productCategories'] ) ) { 
foreach ( $_POST['productCategories'] as $cat ) $productCategories[] = 
preg_replace( "/[^\'\-\ a-zA-Z0-9]/", "", $cat ); 
}

$message = isset( $_POST['message'] ) ? preg_replace( "/(From:|To:|BCC:|CC:|Subject:|Content-Type:)/", "", $_POST['message'] ) : ""; 

if ( $productCategories ) { 
$message .= "\n\n---\n\nInterested in product categories:\n\n"; 
foreach ( $productCategories as $cat ) $message .= "$cat\n"; 
}

// Si todos los valores existen, envia el mensaje 
if ( $senderName && $senderEmail && $message ) { 
$recipient = RECIPIENT_NAME . " <" . RECIPIENT_EMAIL . ">"; 
$headers = "From: " . $senderName . " <" . $senderEmail . ">"; 
$success = mail( $recipient, EMAIL_SUBJECT, $message, $headers ); 
}

// Devuelve una respuesta al bowser 
?> 
<!doctype html> 
<html> 
<head> 
<title>Gracias</title> <meta charset="utf-8"> 
</head> 
<body> 

<div data-role="page" id="contactResult"> 

<div data-role="header"> 
<h1>LGD Argentina</h1> 
</div> 

<div data-role="content"> 
<?php if ( $success ) { ?> 

<div style="text-align: center;"> 
<h2>Gracias !!!</h2> 
<img src="imagenes/LGD-logo.jpg" width="200" alt="Logo"> 
<p>Gracias por su correo. Lo contactaremos a la brevedad ¡! </p> 
</div> 
<div data-role="footer" data-position="fixed" data-id="nav"> 
<div data-role="navbar"> 
<ul> 
<li><a href="#home">Home</a></li> 
<li><a href="#productos">Productos</a></li> 
<li><a href="#contacto" class="ui-btn-active ui-state-persist">Contacto</a></li> 
</ul> 
</div> 
</div> 

<?php } else { ?> 

<div style="text-align: center;"> 
<h2>Oops!</h2> 
<p style="color: red">No se pudo enviar el mensaje. Por favor, asegúrese de completar todos los campos del formulario.<br><br> 
<a href="#contacto" data-rel="back" data-role="button">Volver al formulario</ a> 
</p> 
</div> 
<?php } ?> 

</div> 



</div> 

</body> 
</html> 


<!doctype html> 
<html lang="en"> 
<head> 

<title>DIGESTO - H.C.D.</title> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!--<link rel="stylesheet"  href="css/jquery.mobile-1.2.0.css" />
<script src="js/jquery.js"></script>
<script src="js/jquery.mobile-1.2.0.js"></script>
-->
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.css" />
<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.js"></script>

<script type="text/javascript" charset="utf-8" src="js/cordova-2.0.0.js"></script>

</head> 

 <div id="Layer1" style="position:absolute;  background:#d8501f; left:1px; top:1px; width:680px; height:107642px; z-index:1"> 

<div data-role="footer" data-id="nav"> 
<div data-role="navbar"> 


<ul>
<li><a href="index.html" data-icon="home">Home</a></li>
<li><a href="rama.html" data-icon="grid">Leyes por Rama</a></li>
<li><a href="consultas.html" data-icon="search" class="ui-btn-active ui-state-persist">Consultas</a></a></li> 
</ul>
</div>
</div>  
<font face=arial, size=2px, color=#FFF> 
<?

$NL = $_POST['NL'];
$Voz = $_POST['Voz'];
$Subvoz = $_POST['Subvoz'];
$Extracto = $_POST['Extracto'];
$Sancion = $_POST['Sancion'];
$Promulgacion = $_POST['Promulgacion'];
$Observaciones = $_POST['Observaciones'];
$PBO = $_POST['PBO'];
$es = $_POST['es'];
$materia = $_POST['materia'];





$host="localhost";
$usuarioh="neito1965";
$claveh="neItoMaVr$1965";
	$enlace = mysql_connect($host,$usuarioh,$claveh);
	mysql_set_charset('utf8', $enlace);
	mysql_select_db("legislatura2015", $enlace); 
	



// Consultar la base de datos
$consulta_mysql='select distinct Voz from leyesydecretosleyesvigentes1 where materia="BANCARIO" order by materia';
$resultado_consulta_mysql=mysql_query($consulta_mysql,$enlace);



echo "<select name='Voz'>";
while($fila=mysql_fetch_array($resultado_consulta_mysql)){
    echo "<option value='".$fila['Voz']."'>".$fila['Voz']."</option>";
}
echo "</select>";


?>





 

</div>


  </form>
</div>
</body>
</html>
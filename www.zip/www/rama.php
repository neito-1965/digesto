<!doctype html> 
<html> 
<head> 

<title>HCD Corrientes - Argentina</title> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--<link rel="stylesheet"  href="css/jquery.mobile-1.2.0.css" />
<script src="js/jquery.js"></script>
<script src="js/jquery.mobile-1.2.0.js"></script>
-->
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.css" />
<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.js"></script>

<script type="text/javascript" charset="utf-8" src="js/cordova-2.0.0.js"></script>

</head> 

<body> 



<!-- rama -->
<!------------->
<div data-role="page" id="rama" style="text-align:center; background:#d8501f; color:#FFF;"> 
<div data-role="header"> 
<h1>PROYECTO DE DIGESTO - H.C.D.</h1>
</div>

<div data-role="footer" data-position="fixed" data-id="nav"> 
<div data-role="navbar"> 

<ul>
<li><a href="#home" data-icon="home">Inicio</a></li>
<li><a href="rama.html" data-icon="grid" class="ui-btn-active ui-state-persist">Leyes por Rama</a></li>
<li><a href="consultas.html" data-icon="search">Consultas</a></a></li> 
</ul>
</div>
</div>

<div data-role="content"> 
<h4 style="text-align: center;">Leyes Consolidadas por Rama de la Provincia de Corrientes de 1821 al 2016</h4> 



<form action="http://www.hcdcorrientes.gov.ar/digesto/legislacion/buscasimple105-pdip.php" method="post" data-ajax="false" data-transition="flip">

<?

$NL = $_POST['NL'];
$Voz = $_POST['Voz'];
$Subvoz = $_POST['Subvoz'];
$Extracto = $_POST['Extracto'];
$Sancion = $_POST['Sancion'];
$Promulgacion = $_POST['Promulgacion'];
$Observaciones = $_POST['Observaciones'];
$PBO = $_POST['PBO'];
$es = $_POST['es'];
$materia = $_POST['materia'];
$cv = $_POST['cv'];





$host="localhost";
$usuarioh="neito1965";
$claveh="neItoMaVr$1965";
	$enlace = mysql_connect($host,$usuarioh,$claveh);
	mysql_set_charset('utf8', $enlace);
	mysql_select_db("legislatura2015", $enlace); 

	// Consultar la base de datos
$consulta_mysql='select distinct materia from leyesydecretosleyesvigentes1 order by materia';
$resultado_consulta_mysql=mysql_query($consulta_mysql,$enlace);


$consulta_mysql1='select distinct Voz from leyesydecretosleyesvigentes1 order by Voz';
$resultado_consulta_mysql1=mysql_query($consulta_mysql1,$enlace);
  

echo "<select name='materia'>";
while($fila=mysql_fetch_array($resultado_consulta_mysql)){
    echo "<option value='".$fila['materia']."'>".$fila['materia']."</option>";
}
echo "</select>";

echo "<select name='Voz'>";
while($fila=mysql_fetch_array($resultado_consulta_mysql1)){
    echo "<option value='".$fila['Voz']."'>".$fila['Voz']."</option>";
}
echo "</select>";


?>


    </b></font></font><br>
    <font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><font color="#000066"><b>
    
    </b></font></font> <font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><font color="#000066"><b>
    <input type="submit" data-theme="b" data-icon="search" data-inline="true" value="Buscar" name="BEnviar">
    </b></font></font><br>
  </p>
</div> 

<div data-role="footer" data-position="fixed" data-id="nav"> 
<div data-role="navbar"> 

<ul>
<li><a href="index.html" data-icon="home">Inicio</a></li>
<li><a href="rama.html" data-icon="grid" class="ui-btn-active ui-state-persist">Leyes por Rama</a></li>
<li><a href="consultas.html" data-icon="search">Consultas</a></a></li> 
</ul>
</div>
</div>

</body> 
</html>
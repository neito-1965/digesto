<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Consultas de Decretos Leyes de la Provincia de Corrientes</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<body bgcolor="#FFFFFF" text="#FFFFFF" background="FONDO.GIF">

<div id="Layer1" style="position:absolute; left:30px; top:40px; width:954px; height:4432px; z-index:1"> 


     

<?

$NDL = $_POST['NDL'];
$PG = $_POST['PG'];
$Voz = $_POST['Voz'];
$Subvoz = $_POST['Subvoz'];
$Extracto = $_POST['Extracto'];
$Promulgacion = $_POST['Promulgacion'];
$PBO = $_POST['PBO'];
$Observaciones = $_POST['Observaciones'];


$host="localhost";
$usuarioh="neito1965";
$claveh="neItoMaVr$1965";
	$enlace = mysql_connect($host,$usuarioh,$claveh);
	mysql_set_charset('utf8', $enlace);
	mysql_select_db("legislatura2015", $enlace); 

if ($NDL<>"") {
$SQL1="SELECT* FROM decreto_ley  WHERE NDL LIKE '%$NDL%' ORDER BY NDL ASC";

}if ($PG<>"") {
$SQL1="SELECT* FROM decreto_ley WHERE PG LIKE '%$PG%' ORDER BY PG ASC";

}if ($Voz<>"") {
$SQL1="SELECT* FROM decreto_ley WHERE Voz LIKE '%$Voz%' ORDER BY NDL ASC";

}if ($Subvoz<>"") {
$SQL1="SELECT* FROM decreto_ley WHERE Subvoz LIKE '%$Subvoz%' ORDER BY NDL ASC";

}if ($Extracto<>"") {
$SQL1="SELECT* FROM decreto_ley WHERE Extracto LIKE '%$Extracto%' ORDER BY NDL ASC";

}if ($Promulgacion<>"") {
$SQL1="SELECT* FROM decreto_ley WHERE Promulgacion LIKE '%$Promulgacion%' ORDER BY NDL ASC";

}if ($PBO<>"") {
$SQL1="SELECT* FROM decreto_ley WHERE PBO LIKE '%$PBO%' ORDER BY NDL ASC";

}if ($De_Observaciones<>"") {
$SQL1="SELECT* FROM decreto_ley WHERE De_Observaciones LIKE '%Observaciones%' ORDER BY NDL ASC";


}
 


$result=mysql_query($SQL1,$enlace);


if ($row =mysql_fetch_array ($result)){ 

echo "<table border = '1'> \n"; 

echo "<tr BGCOLOR=#400080> \n";

echo "<td><font face=verdana, size=1px, color=#FFF><b>Decreto Ley</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#FFF><b>Periodo Gubernamental</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#FFF><b>Tema</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#FFF><b>Subtema</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#FFF><b>Extracto</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#FFF><b>Fecha Promulgación</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#FFF><b>Fecha de P.B.O.</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#FFF><b>Vigencia</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#FFF><b>.tif</b></td> \n";
//echo "<td><font face=verdana, size=1px, color=#0000FF><b>Texto Completo del Anexo</b></td> \n";
echo "</tr> \n";


while ($field = mysql_fetch_field($result)){ 

echo "<td><b>$field->name</b></td> \n"; 

} 

echo "</tr> \n"; 

do { 
echo "<tr> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["NDL"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["PG"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Voz"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Subvoz"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Extracto"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Promulgacion"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["PBO"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Observaciones"]."</td> \n";
//echo "<td><font face=verdana, size=1px, color=#FFFFFF>".$row["Le_NLey"]."</td> \n";
//echo "<td>".$row["Le_NLey"]."</td> \n";

$valor2='.doc';
$valor1=$row["PG"];

$valor=$row["NDL"];
$valor=implode('-',explode('/',$valor));
//$valor1=$row["anexoitu"].$row["nordeituzaingo"].$row["tdaitu"];
echo "<td><A HREF=http://www.hcdcorrientes.gov.ar/Decretos-leyes/DecreLeyP$valor-$valor1.tif><font face=verdana, size=1px, color=#EB0101>Decreto Ley</font></A> </td>";
//echo "<td><A HREF=Ley\"$valor\".doc><font face=verdana, size=1px, color=#00FF00>Ley</font></A> </td>";
//echo "<td><A HREF=\"$valor1\"><font face=verdana, size=1px, color=#00FF00>Anexo</font></A> </td>";
echo "</tr> \n"; 

} while ($row = mysql_fetch_array($result)); 
 
echo "</table> \n"; 


} else { 

?>

  <script language="JavaScript">     
		window.top.location ="http://www.hcdcorrientes.gov.ar/digesto/legislacion/index.html";    
		alert("No existe ninguna Ley con los datos ingresados. Intente nuevamente.");
	
</script>

<?

}
?>
 
</div>
<div id="Layer2" style="position:absolute; left:450; top:1px; width:48px; height:26px; z-index:2"> 
  <form name="contacto" method="get" action="http://www.hcdcorrientes.gov.ar/digesto/legislacion/index.html" target="_top">
    <input type="submit" name="Submit" value="  Cerrar ">

  </form>
</div>
</body>
</html>
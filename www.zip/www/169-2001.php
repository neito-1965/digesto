<!doctype html> 
<html lang="en"> 
<head> 

<title>DIGESTO - H.C.D.</title> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!--<link rel="stylesheet"  href="css/jquery.mobile-1.2.0.css" />
<script src="js/jquery.js"></script>
<script src="js/jquery.mobile-1.2.0.js"></script>
-->
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.css" />
<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.js"></script>

<script type="text/javascript" charset="utf-8" src="js/cordova-2.0.0.js"></script>

</head> 

<div id="Layer1" style="position:absolute;  background:#d8501f; left:1px; top:1px; width:850px; height:107642px; z-index:1"> 

<div data-role="footer" data-id="nav"> 
<div data-role="navbar"> 


<ul>
<li><a href="index.html" data-icon="home">Home</a></li>
<li><a href="rama.html" data-icon="grid">Leyes por Rama</a></li>
<li><a href="consultas.html" data-icon="search" class="ui-btn-active ui-state-persist">Consultas</a></a></li> 
</ul>
</div>
</div>  
<font face=arial, size=2px, color=#FFF> 
<?

$NL =utf8_encode($_POST['NL']);
$Voz =utf8_encode($_POST['Voz']);
$Subvoz =utf8_encode($_POST['Subvoz']);
$Extracto =utf8_encode($_POST['Extracto']);
$Sancion =utf8_encode($_POST['Sancion']);
$Promulgacion =utf8_encode($_POST['Promulgacion']);
$Observaciones =utf8_encode($_POST['Observaciones']);
$PBO =utf8_encode($_POST['PBO']);
$es =utf8_encode($_POST['es']);
$materia =utf8_encode($_POST['materia']);
$nlm =utf8_encode($_POST['nlm']);
$regla =utf8_encode($_POST['regla']);





$host="localhost";
$usuarioh="neito1965";
$claveh="neItoMaVr$1965";
	$enlace = mysql_connect($host,$usuarioh,$claveh);
	mysql_query("SET NAMES 'utf-8'");
	mysql_set_charset('utf8', $enlace);
	mysql_select_db("legislatura2015", $enlace); 
	
//$valor5=$row["NL"];	
//$SQL2="SELECT* FROM leyesydecretosleyesvigentes1  WHERE nlm='1482' ORDER BY NL ASC";
$SQL2="SELECT* FROM leyesydecretosleyesvigentes1  WHERE nlm1='169/2001' ORDER BY NL ASC";
$result=mysql_query($SQL2,$enlace);

$numero = mysql_num_rows($result); // obtenemos el número de filas

echo 'El Decreto Ley N° 169/2001 tiene las siguientes modificaciones y un Total de registros encontrados de: '.$numero.'';  // imprimos en pantalla el número generado

if ($row=mysql_fetch_array ($result)){ 

echo "<table border = '1'> \n"; 

echo "<tr BGCOLOR=#400080> \n";


echo "<td><font face=arial, size=1px, color=#FFF>Nro. Ley/DLey</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Tema</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Subtema</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Vigencia</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Texto Ley/DL</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Con o sin Modificación</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Con o sin Reglamentación</td> \n";
//echo "<td><font face=arial, size=1px, color=#FFF>Archivo.pdf</td> \n";
//echo "<td><font face=arial, size=1px, color=#FFF>Archivo de DLey.tif</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Extracto</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Fecha Sanción</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Fecha Promulgación</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Observaciones</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Fecha P.B.O.</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Materia</td> \n";

echo "</tr> \n";


while ($field = mysql_fetch_field($result)){ 

echo "<td><b>$field->name</b></td> \n"; 

} 

echo "</tr> \n"; 
do { 
echo "<tr BGCOLOR=#FFF> \n"; 



//echo utf8_decode($row['Extracto']);

echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['NL'])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['Voz'])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['Subvoz'])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['es'])."</td> \n";
//echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["nlm"]."</td> \n";
$valor2=$row["NL"];
$valor3=implode('-',explode('/',$valor2));

$valor4=$row["reglad"];
$valor5=implode('-',explode('/',$valor4));

//$valor2=$row["NL"];
//echo "<td><a href=http://www.hcdcorrientes.gov.ar/Leyes-texto/Ley$valor2.doc><font face=verdana, size=1px, color=#EB0101>Ley</font></A> </td>";
echo "<td><a href=http://www.hcdcorrientes.gov.ar/Leyes-texto/Ley$valor3.pdf target='_BLANK'><font face=verdana, size=1px, color=#EB0101>Ley</font></A> </td>";

if ($row['modi'] == 'Con modificaciones') {

echo "<td><font face=verdana, size=1px, color=#0000FF><a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/$valor3.php' target='_BLANK'>".utf8_decode($row["modi"])."</a></td> \n";
} else {
	echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["modi"])."</td> \n";
	//echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["regla"])."</td> \n";
}


if ($row['regla'] == 'Reglamentada') {

echo "<td><font face=verdana, size=1px, color=#0000FF><a href='http://www.hcdcorrientes.gov.ar/digesto/legislacion/$valor5.pdf' target='_BLANK'>".utf8_decode($row["regla"])."</a></td> \n";
} else {
	//echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["modi"])."</td> \n";
	echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row["regla"])."</td> \n";
}

//$valor1=$row["PG"];

//$valor=$row["NL"];
//$valor=implode('-',explode('/',$valor));
//$valor1=$row["anexoitu"].$row["nordeituzaingo"].$row["tdaitu"];
//echo "<td><A HREF=http://www.hcdcorrientes.gov.ar/Decretos-leyes/DecreLeyP$valor.tif><font face=verdana, size=1px, color=#00FF00>Decreto Ley</font></A> </td>";

echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['Extracto'])."</td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['Sancion'])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['Promulgacion'])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['Observaciones'])."</td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['PBO'])."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".utf8_decode($row['materia'])."</td> \n";





//echo "<td><A HREF=Ley\"$valor\".doc><font face=verdana, size=1px, color=#00FF00>Ley</font></A> </td>";
//echo "<td><A HREF=\"$valor1\"><font face=verdana, size=1px, color=#00FF00>Anexo</font></A> </td>";
echo "</tr> \n"; 
 
} while ($row = mysql_fetch_array($result)); 

echo "</table> \n"; 


} else { 
$Rc=$Rc+1


?>


  <script language="JavaScript">     
		window.top.location ="http://www.hcdcorrientes.gov.ar/digesto/legislacion/index.html";    
		alert("ESTA LEY QUE ESTA CONSULTANDO NO ESTA MAS EN VIGENCIA");
	
</script>
echo "<td><font face=arial, size=1px, color=#FFF>La Ley N° 1566 tiene las sigueintes modificaciones y un Total de registros encontradosecho</td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Rc"]."</td> \n";
<?

}
?>
 


</div>


  </form>
</div>
</body>
</html>
<!doctype html> 
<html lang="en"> 
<head> 

<?php
$usuario = 'neito1965'; // Nombre del usuario para la base de datos.
$password = 'neItoMaVr$1965'; // Contraseña para la base de datos.
$servidor = 'localhost'; // Servidor para la base de datos.
$bd = 'legislatura2015'; // Nombre de la base de datos.
 
/* Nos conectamos a la base de datos, o en caso contrario mostramos error */
$conexion = New mysqli($servidor,$usuario,$password,$bd);
if ($conexion->connect_errno) { die('Error al conectar a la base de datos'); }
 
/* Si el código de materia ha sido enviado... */
if(!empty($_POST['cm'])){
 
   /* Nos aseguramos de que el cm es solo NUMERICO
   para evitar sqli */
   $codigo = (int)$_POST['cm'];
 
   /* Esta es la consulta para sacar todos  subtemas y sus temas  indicado
   el código de materia */
   $query = "SELECT cv, csv, cm FROM leyesydecretosleyesvigentes1 WHERE cm='".$codigo."'";
 
   /* Realizamos la consulta */
   $resultado = $conexion->query($query);
 
   /* Mostramos la lista */
   echo 'Los temas y subtemas para esta materia son: <select name="materia">';
   while($row = $resultado->fetch_assoc()){
      echo '<option>';
      echo 'Materia: '.$row['materia']; // Materia
      echo ' -- Tema: '.$row['voz']; // temas
	  echo ' -- Subtema: '.$row['subvoz']; // subtemas
      echo '</option>';
   }
   echo '</select>';
 
/* En caso de que el código de materia no haya sido enviado... */
} else {
 
   /* Preparamos la consulta */
   $query = "SELECT cm,matria FROM leyesydecretosleyesvigentes1";
 
   /* Realizamos la consulta */
   $resultado = $conexion->query($query);
 
   /* Creamos el formulario y mostramos la lista de materias */
      echo "Por favor, seleciona una materia: ";
      echo '<form action="" method="POST"><select name="cm">';
      while($row = $resultado->fetch_assoc()){
         echo '<option value="'.$row['cm'].'">'.$row['materia'].'</option>';
      }
      // Cerramos lista + boton enviar + cerramos formulario
      echo '</select> <input type="submit" value="Enviar" /></form>';
}
?>
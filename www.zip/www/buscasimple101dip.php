<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Consultas de Leyes de la Provincia de Corrientes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<body bgcolor="#FFFFFF" text="#FFFFFF" background="FONDO.GIF">

<div id="Layer1" style="position:absolute; left:30px; top:40px; width:954px; height:4432px; z-index:1"> 


<?

$NL = $_POST['NL'];
$Voz = $_POST['Voz'];
$Subvoz = $_POST['Subvoz'];
$Extracto = $_POST['Extracto'];
$Sancion = $_POST['Sancion'];
$Promulgacion = $_POST['Promulgacion'];
$PBO = $_POST['PBO'];
$Veto = $_POST['Veto'];
$Observaciones = $_POST['Observaciones'];



$host="localhost";
$usuarioh="mavr2014";
$claveh="mavr1965";
	$enlace = mysql_connect($host,$usuarioh,$claveh); 
	mysql_select_db("legislatura", $enlace); 
	

if ($NL<>"") {
$SQL1="SELECT* FROM leyes_provinciales  WHERE NL LIKE '%$NL%' ORDER BY NL ASC";

}if ($Voz<>"") {
$SQL1="SELECT* FROM leyes_provinciales WHERE Voz LIKE '%$Voz%' ORDER BY NL ASC";

}if ($Subvoz<>"") {
$SQL1="SELECT* FROM leyes_provinciales WHERE Subvoz LIKE '%$Subvoz%' ORDER BY NL ASC";

}if ($Extracto<>"") {
$SQL1="SELECT* FROM leyes_provinciales WHERE Extracto LIKE '%$Extracto%' ORDER BY NL ASC";

}if ($Sancion<>"") {
$SQL1="SELECT* FROM leyes_provinciales WHERE Sancion LIKE '%$Sancion%' ORDER BY NL ASC";

}if ($Promulgacion<>"") {
$SQL1="SELECT* FROM leyes_provinciales WHERE Promulgacion LIKE '%$Promulgacion%' ORDER BY NL ASC";

}if ($PBO<>"") {
$SQL1="SELECT* FROM leyes_provinciales WHERE PBO LIKE '%$PBO%' ORDER BY NL ASC";

}if ($Veto<>"") {
$SQL1="SELECT* FROM leyes_provinciales WHERE Veto LIKE '%$Veto%' ORDER BY NL ASC";

}if ($Observaciones<>"") {
$SQL1="SELECT* FROM leyes_provinciales WHERE Observaciones LIKE '%Observaciones%' ORDER BY NL ASC";

}
 


$result=mysql_query($SQL1,$enlace);


if ($row =mysql_fetch_array ($result)){ 

echo "<table border = '1'> \n"; 

echo "<tr BGCOLOR=#FFFFFF> \n";


echo "<td><font face=verdana, size=1px, color=#0000FF><b>Nro. de Ley</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF><b>Tema</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF><b>Subtema</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF><b>Extracto</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF><b>Fecha de Sanci�n</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF><b>Fecha de Promulgaci�n</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF><b>Fecha de P.B.O.</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF><b>Estado de la Ley</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF><b>Texto de la Ley en archivo punto doc</b></td> \n";
echo "<td><font face=verdana, size=1px, color=#0000FF><b>Texto de la Ley en archivo punto pdf</b></td> \n";
echo "</tr> \n";


while ($field = mysql_fetch_field($result)){ 

echo "<td><b>$field->name</b></td> \n"; 

} 

echo "</tr> \n"; 

do { 
echo "<tr> \n"; 
echo "<td><font face=verdana, size=1px, color=#FFFFFF>".$row["NL"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#FFFFFF>".$row["Voz"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#FFFFFF>".$row["Subvoz"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#FFFFFF>".$row["Extracto"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#FFFFFF>".$row["Sancion"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#FFFFFF>".$row["Promulgacion"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#FFFFFF>".$row["PBO"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#FFFFFF>".$row["Observaciones"]."</td> \n"; 
//echo "<td><font face=verdana, size=1px, color=#FFFFFF>".$row["Veto"]."</td> \n";



$valor2='.doc';

$valor=$row["NL"];
//$valor1=$row["anexoitu"].$row["nordeituzaingo"].$row["tdaitu"];
echo "<td><A HREF=http://www.hcdcorrientes.gov.ar/Leyes-texto/Ley$valor.doc><font face=verdana, size=1px, color=#00FF00>Ley</font></A> </td>";
echo "<td><A HREF=http://www.hcdcorrientes.gov.ar/Leyes-texto/Ley$valor.pdf><font face=verdana, size=1px, color=#00FF00>Ley</font></A> </td>";
//echo "<td><A HREF=Ley\"$valor\".doc><font face=verdana, size=1px, color=#00FF00>Ley</font></A> </td>";
//echo "<td><A HREF=\"$valor1\"><font face=verdana, size=1px, color=#00FF00>Anexo</font></A> </td>";
echo "</tr> \n"; 

} while ($row = mysql_fetch_array($result)); 
 
echo "</table> \n"; 


} else { 

?>

  <script language="JavaScript">     
		window.top.location ="http://www.hcdcorrientes.gov.ar/index.html";    
		alert("No existe ninguna Ley con los datos ingresados. Intente nuevamente.");
	
</script>

<?

}
?>
 
</div>
<div id="Layer2" style="position:absolute; left:450; top:1px; width:48px; height:26px; z-index:2"> 
  <form name="form1" method="get" action="http://www.hcdcorrientes.gov.ar/index.htm" target="_top">
    <input type="submit" name="Submit" value="  Cerrar ">

  </form>
</div>
</body>
</html>
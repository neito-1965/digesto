<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">


<form action="" method="post">
<input type="text" name="buscar">
<input type="submit" name="Submit" value="Buscar">
</form>


<?php




if(isset($_POST['Submit'])) {



include_once('class.pdf2text.php');
require("class.filetotext.php");

$directorio = opendir("http://www.hcdcorrientes.gov.ar/Leyes-texto"); //ruta actual
while ($archivo = readdir($directorio)) //obtenemos un archivo y luego otro sucesivamente
{

       

        $url = 'http://www.hcdcorrientes.gov.ar/Leyes-texto'.$archivo;

$a = new PDF2Text();
$a->setFilename($url);
$a->decodePDF();
$pdf = utf8_encode($a->output());



$larCharsNoAble = array("Ñ","á","é","í","ó","ú","Á","É","Í","Ó","Ú","ñ","À","Ã","Ì","Ò","Ù","Ã™","Ã ","Ã¨","Ã¬","Ã²","Ã¹","ç","Ç","Ã¢","ê","Ã®","Ã´","Ã»","Ã‚","ÃŠ","ÃŽ","Ã”","Ã›","ü","Ã¶","Ã–","Ã¯","Ã¤","«","Ò","Ã ","Ã„","Ã‹");
$larCharsAble = array("N","a","e","i","o","u","A","E","I","O","U","n","N","A","E","I","O","U","a","e","i","o","u","c","C","a","e","i","o","u","A","E","I","O","U","u","o","O","i","a","e","U","I","A","E");
$texto = str_replace($larCharsNoAble, $larCharsAble, $pdf);


$cadena_solicitada   = $_POST['buscar'];
$larCharsNoAble = array("Ñ","á","é","í","ó","ú","Á","É","Í","Ó","Ú","ñ","À","Ã","Ì","Ò","Ù","Ã™","Ã ","Ã¨","Ã¬","Ã²","Ã¹","ç","Ç","Ã¢","ê","Ã®","Ã´","Ã»","Ã‚","ÃŠ","ÃŽ","Ã”","Ã›","ü","Ã¶","Ã–","Ã¯","Ã¤","«","Ò","Ã ","Ã„","Ã‹");
$larCharsAble = array("N","a","e","i","o","u","A","E","I","O","U","n","N","A","E","I","O","U","a","e","i","o","u","c","C","a","e","i","o","u","A","E","I","O","U","u","o","O","i","a","e","U","I","A","E");
$post = str_replace($larCharsNoAble, $larCharsAble, $cadena_solicitada);


$posicion_coincidencia = stripos($texto, $post);




if ($posicion_coincidencia == true) {
echo 'Se ha encontrado "'.$post.'"" en el archivo <a href="'.$url.'">'.$archivo.'</a><br>';
} 


$docObj = new Filetotext($url);
$doc = utf8_encode($docObj->convertToText());


$larCharsNoAble = array("Ñ","á","é","í","ó","ú","Á","É","Í","Ó","Ú","ñ","À","Ã","Ì","Ò","Ù","Ã™","Ã ","Ã¨","Ã¬","Ã²","Ã¹","ç","Ç","Ã¢","ê","Ã®","Ã´","Ã»","Ã‚","ÃŠ","ÃŽ","Ã”","Ã›","ü","Ã¶","Ã–","Ã¯","Ã¤","«","Ò","Ã ","Ã„","Ã‹");
$larCharsAble = array("N","a","e","i","o","u","A","E","I","O","U","n","N","A","E","I","O","U","a","e","i","o","u","c","C","a","e","i","o","u","A","E","I","O","U","u","o","O","i","a","e","U","I","A","E");
$texto = str_replace($larCharsNoAble, $larCharsAble, $doc);


$solicitada   = $_POST['buscar'];
$larCharsNoAble = array("Ñ","á","é","í","ó","ú","Á","É","Í","Ó","Ú","ñ","À","Ã","Ì","Ò","Ù","Ã™","Ã ","Ã¨","Ã¬","Ã²","Ã¹","ç","Ç","Ã¢","ê","Ã®","Ã´","Ã»","Ã‚","ÃŠ","ÃŽ","Ã”","Ã›","ü","Ã¶","Ã–","Ã¯","Ã¤","«","Ò","Ã ","Ã„","Ã‹");
$larCharsAble = array("N","a","e","i","o","u","A","E","I","O","U","n","N","A","E","I","O","U","a","e","i","o","u","c","C","a","e","i","o","u","A","E","I","O","U","u","o","O","i","a","e","U","I","A","E");
$post = str_replace($larCharsNoAble, $larCharsAble, $solicitada);


$coincidencia = stripos($texto, $post);


if ($coincidencia == true) {
echo 'Se ha encontrado "'.$post.'"" en el archivo <a href="'.$url.'">'.$archivo.'</a><br>';
} 


 }

}


?>


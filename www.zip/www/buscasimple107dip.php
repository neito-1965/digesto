<!doctype html> 
<html lang="en"> 
<head> 

<title>DIGESTO - H.C.D.</title> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--<link rel="stylesheet"  href="css/jquery.mobile-1.2.0.css" />
<script src="js/jquery.js"></script>
<script src="js/jquery.mobile-1.2.0.js"></script>
-->
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.css" />
<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.1.0/jquery.mobile-1.1.0.min.js"></script>

<script type="text/javascript" charset="utf-8" src="js/cordova-2.0.0.js"></script>

</head> 

<div id="Layer1" style="position:absolute;  background:#d8501f; left:1px; top:1px; width:700px; height:15432px; z-index:1"> 

<div data-role="footer" data-id="nav"> 
<div data-role="navbar"> 

<ul>
<li><a href="index.html" data-icon="home">Home</a></li>
<li><a href="rama1.html" data-icon="grid">Leyes por Rama</a></li>
<li><a href="consultas.html" data-icon="search" class="ui-btn-active ui-state-persist">Consultas</a></a></li> 
</ul>
</div>
</div>
<font face=arial, size=2px, color=#FFF>
<?

$NL = $_POST['NL'];
$Voz = $_POST['Voz'];
$Subvoz = $_POST['Subvoz'];
$Extracto = $_POST['Extracto'];
$Sancion = $_POST['Sancion'];
$Promulgacion = $_POST['Promulgacion'];
$Observaciones = $_POST['Observaciones'];
$PBO = $_POST['PBO'];
$es = $_POST['es'];
$Veto = $_POST['Veto'];


$host="localhost";
$usuarioh="neito1965";
$claveh="neItoMaVr$1965";
	$enlace = mysql_connect($host,$usuarioh,$claveh);
	mysql_set_charset('utf8', $enlace);
	mysql_select_db("legislatura2015", $enlace); 
	

if ($NL<>"") {
$SQL1="SELECT* FROM lvigentes  WHERE NL LIKE '%$NL%' ORDER BY NL ASC";
}if ($Voz<>"") {
$SQL1="SELECT* FROM lvigentes WHERE Voz LIKE '%$Voz%' ORDER BY NL ASC";

}if ($Subvoz<>"") {
$SQL1="SELECT* FROM lvigentes WHERE Subvoz LIKE '%$Subvoz%' ORDER BY NL ASC";

}if ($Extracto<>"") {
$SQL1="SELECT* FROM lvigentes WHERE Extracto LIKE '%$Extracto%' ORDER BY NL ASC";

}if ($Sancion<>"") {
$SQL1="SELECT* FROM lvigentes WHERE Sancion LIKE '%$Sancion%' ORDER BY NL ASC";

}if ($Promulgacion<>"") {
$SQL1="SELECT* FROM lvigentes WHERE Promulgacion LIKE '%$Promulgacion%' ORDER BY NL ASC";

}if ($Observaciones<>"") {
$SQL1="SELECT* FROM lvigentes WHERE Observaciones LIKE '%Observaciones%' ORDER BY NL ASC";

}if ($PBO<>"") {
$SQL1="SELECT* FROM lvigentes WHERE PBO LIKE '%$PBO%' ORDER BY NL ASC";

}if ($es<>"") {
$SQL1="SELECT* FROM lvigentes WHERE es LIKE '%$es%' ORDER BY NL ASC";

}if ($Veto<>"") {
$SQL1="SELECT* FROM lvigentes WHERE Veto LIKE '%$Veto%' ORDER BY NL ASC";


}
 


$result=mysql_query($SQL1,$enlace);

$numero = mysql_num_rows($result); // obtenemos el número de filas

echo 'El número de Leyes encontrados es: '.$numero.'';  // imprimos en pantalla el número generado

if ($row=mysql_fetch_array ($result)){ 

echo "<table border = '1'> \n"; 

echo "<tr BGCOLOR=#400080> \n";


echo "<td><font face=arial, size=1px, color=#FFF>Nro. Ley</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Tema</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Subtema</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Vigencia</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Archivo.doc</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Archivo.pdf</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Extracto</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Fecha Sanción</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Fecha Promulgación</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Fecha P.B.O.</td> \n";
echo "<td><font face=arial, size=1px, color=#FFF>Estado de la Ley</td> \n";

echo "</tr> \n";


while ($field = mysql_fetch_field($result)){ 

echo "<td><b>$field->name</b></td> \n"; 

} 

echo "</tr> \n"; 
do { 
echo "<tr BGCOLOR=#FFF> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["NL"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Voz"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Subvoz"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["es"]."</td> \n";
$valor2=$row["NL"];
echo "<td><a href=http://www.hcdcorrientes.gov.ar/Leyes-texto/Ley$valor2.doc><font face=verdana, size=1px, color=#EB0101>Ley</font></A> </td>";
echo "<td><a href=http://www.hcdcorrientes.gov.ar/Leyes-texto/Ley$valor2.pdf><font face=verdana, size=1px, color=#EB0101>Ley</font></A> </td>";
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Extracto"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Sancion"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Promulgacion"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["PBO"]."</td> \n"; 
echo "<td><font face=verdana, size=1px, color=#0000FF>".$row["Obsevaciones"]."</td> \n";





//echo "<td><A HREF=Ley\"$valor\".doc><font face=verdana, size=1px, color=#00FF00>Ley</font></A> </td>";
//echo "<td><A HREF=\"$valor1\"><font face=verdana, size=1px, color=#00FF00>Anexo</font></A> </td>";
echo "</tr> \n"; 

} while ($row = mysql_fetch_array($result)); 
 
echo "</table> \n"; 


} else { 

?>



  <script language="JavaScript">     
		window.top.location ="http://www.hcdcorrientes.gov.ar/digesto/legislacion/index.html";    
		alert("ESTA LEY QUE ESTA CONSULTANDO NO ESTA MAS EN VIGENCIA");
	
</script>

<?

}
?>
 


</div>


  </form>
</div>
</body>
</html>